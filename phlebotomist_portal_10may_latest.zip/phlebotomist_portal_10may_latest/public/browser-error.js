setTimeout(function () {
  var root = document.getElementById('root')
  if (root.innerText === '') {
    root.innerText = 'Your browser is not supported, please try again using Google Chrome, Firefox or Safari.'
  }
}, 4000)
