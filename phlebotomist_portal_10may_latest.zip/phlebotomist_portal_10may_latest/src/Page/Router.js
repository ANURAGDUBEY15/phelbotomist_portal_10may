import React from "react";
import { Routes, Route } from "react-router-dom";
import LoginForm from "../views/LoginForm";
import LoginPage from "../views/LoginPage";
import Index from "../views/Index";
import PatientRecord from "../views/PatientRecords/PatientRecord";
import AppointmentRecord from "../views/AppointmentRecords/AppointmentRecord";
import Accounts from "../views/Accounts/Accounts";
import Resources from "../views/Resources";
import Activation from "../views/Activation/Activation";
import ConfirmMFA from "../views/ConfirmMFA";

export default () => {
  return (
    <Routes>
      <Route path="/" element={<Index/>} />
      <Route path="/login-form" element={<LoginForm />} />
      <Route path="/login-page" element={<LoginPage />} />
      <Route path="/patient-record" element={<PatientRecord />} />
      <Route path="/appointment-record" element={<AppointmentRecord />} />
      <Route path="/account" element={<Accounts />} />
      <Route path="/resources" element={<Resources />} />
      <Route path="/activation" element={<Activation />} />
      <Route path="/mfa" element={<ConfirmMFA />} />
    </Routes>
  );
};
