import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import { Button as BootstrapButton } from "react-bootstrap";
import { Dropdown } from "react-bootstrap";
import { Image } from "react-bootstrap";

/* Define a function to dynamically import icons */
const importIcon = (iconName) =>
  import(`react-bootstrap-icons/dist/icons/${iconName}.js`);

/**
 * Primary UI component for user interaction
 */
export const Button = ({
  variant,
  className: userClassName,
  size,
  label,
  onClick,
  icon,
  target,
  isDisabled,
  iconOrder,
  svg,
  type,
  items,
  username,
  initials,
  ...props
}) => {
  const [IconComponent, setIconComponent] = useState(null);
  const [validComponent, setValidComponent] = useState(null);
  const direction = iconOrder === "On left" ? "rtl" : "ltr";

  /* Load icon dynamically when icon prop changes */
  useEffect(() => {
    if (icon) {
      importIcon(icon)
        .then((module) => {
          setIconComponent(module.default);
          setValidComponent(null);
        })
        .catch((error) => {
          setIconComponent(null);
          setValidComponent("Please enter a valid Icon name");
        });
    } else {
      setIconComponent(null);
    }
  }, [icon]);

  const variantClassName = `btn btn--${variant}`;
  const sizeClassName = `btn--${size}`;
  const rel = target ? "noopener noreferrer" : null;

  /* Concatenate the user-provided className with other className names */
  const combinedClassName = `${variantClassName} ${sizeClassName} ${userClassName}`;

  return (
    <>
      {type !== "dropdown" ? (
        <BootstrapButton
          type={type}
          className={combinedClassName}
          style={{ outline: "none", direction }}
          onClick={onClick}
          disabled={isDisabled}
          variant={variant}
          svg={svg}
          {...props}
          rel={rel}
          target={target ? "_blank" : null}
        >
          <div className="icon">{svg && <img src={svg} />}</div>
          <span>{label}</span>
          {IconComponent && <IconComponent className="icon-margin" />}
        </BootstrapButton>
      ) : (
        <Dropdown className="profile-color">
          <Dropdown.Toggle
            id="dropdown-basic"
            className={combinedClassName}
            variant={variant}
            items={items}
            username={username}
            initials={initials}
            svg={svg}
          >
            {svg && <Image src={svg} alt="svg" fluid />}

            <span>{label}</span>
          </Dropdown.Toggle>

          <Dropdown.Menu className="">
            {username && ( // Render only if username exists
              <Dropdown.Item href="#">
                <span className="profile-circle">{initials}</span>
                {username}
              </Dropdown.Item>
            )}
            {items &&
              Array.isArray(items) &&
              items.map((item, index) => (
                <Dropdown.Item key={index} href={item.href}>
                  {item.label}
                </Dropdown.Item>
              ))}
          </Dropdown.Menu>
        </Dropdown>
      )}
      {validComponent && (
        <div className="icon-validation">{validComponent}</div>
      )}
    </>
  );
};

/* Default props for buttons */
Button.defaultProps = {
  variant: "primary",
  size: "medium",
  isDisabled: false,
  iconOrder: "On right",
};

/* PropTypes for buttons */
Button.propTypes = {
  variant: PropTypes.oneOf([
    "primary",
    "secondary",
    "danger",
    "grey",
    "outline",
    "olive",
    "offwhite",
    "white",
    "light-grey",
  ]),
  size: PropTypes.oneOf(["small", "medium", "large"]),
  label: PropTypes.string,
  icon: PropTypes.string,
  svg: PropTypes.string,
  target: PropTypes.bool,
  onClick: PropTypes.func,
  isDisabled: PropTypes.bool,
  className: PropTypes.string,
  iconOrder: PropTypes.oneOf(["On left", "On right"]),
};
