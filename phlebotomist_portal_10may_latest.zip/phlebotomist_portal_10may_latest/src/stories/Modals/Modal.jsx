
import {Button} from '../Buttons/Button';
import PropTypes from "prop-types";
import {Modal} from 'react-bootstrap';
import { Markdown } from '@storybook/blocks';

function SuccessModal(props) {
  

  return (
    <>
      <Modal show={props.show} className='p-4 text-center success-modal' centered onHide={props.handleClose}>
        <Modal.Header  className=' border-0 align-self-center  ' >
          <Modal.Title>{props.heading}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Markdown>{props.message}</Markdown>
        </Modal.Body>
        {/* <Modal.Footer className=' justify-content-center border-0 '> */}
          {/* <Button onClick={handleClose}>Close</Button> */}
          <Button type='submit' className={'mb-4  align-self-center '} variant={'danger'} onClick={props.handleClose} label={'CONTINUE'}></Button>
        {/* </Modal.Footer> */}
      </Modal>
    </>
  );
}

export default SuccessModal;

SuccessModal.propTypes = {
  /**
   * Button contents
   */
  heading: PropTypes.string,
  /**
   * Optional click handler
   */
  message: PropTypes.string.isRequired, // Fix typo here
  show: PropTypes.bool,
};

SuccessModal.defaultProps = {
  heading: '',
  message: '<strong>SUCCESS:</strong> Your account \n\n has been created'
};