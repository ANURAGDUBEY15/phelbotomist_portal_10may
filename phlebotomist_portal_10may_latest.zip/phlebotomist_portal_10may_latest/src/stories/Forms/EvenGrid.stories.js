import EvenGrid from './EvenGrid';
import { activationShema } from './validationSchema';
import { activationFields } from './fields';

export default {
  title: 'Components/Forms/EvenGrid',
  component: EvenGrid,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export const Default = {
  args: {
    fields: activationFields,
    validationSchema:activationShema
  },
};


