
import * as yup from 'yup'
import 'yup-phone-lite'

const phoneRegex = /^(?:(?:\+?44)|0)(?:\d{10}|\d{4}\s\d{3}\s\d{4}|\d{3}\s\d{3}\s\d{4}|\d{5}\s\d{4}\s\d{2}|\d{4}\s\d{4}\s\d{2}|\d{4}\s\d{3}\s\d{3})$/
export const loginSchema = yup.object().shape({
  email: yup.string().required('Email is required').email(),
  password: yup
    .string()
    .required('Password is required')
});
export const activationShema = yup.object().shape({
  name: yup.string('Name cannot be a number').required("Name is required"),

  // email: yup.string().required("Email is required").email("Please enter a valid email"),
  password: yup
    .string()
    .required("Password is required")
    .min(8, "Password must be at least 8 characters")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/,
      "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"
    )
    .matches(/^[^\s]+$/, "Password must not contain any spaces")
    .matches(/^(?!.*(\w)\1{2,})/, 'Password must not contain repetitive characters')
    .matches(/^(?!.*(?:abcdefghijklmnopqrstuvwxyz|ABCDEFGHIJKLMNOPQRSTUVWXYZ|01234567890))[\w@$!%*?&]{8,}$/, 'Password must not contain sequential characters'),
  occupation: yup.string().required("Occupation is required"),
  // credentials: yup.string()("Credentials is required"),
  // organisation: yup.string().required("Organisation is required"),
  mobile: yup.string()
    .phone("GB", "Please enter a valid UK phone number"),
  // .matches(phoneRegex, 'Please enter a valid UK number'),

});