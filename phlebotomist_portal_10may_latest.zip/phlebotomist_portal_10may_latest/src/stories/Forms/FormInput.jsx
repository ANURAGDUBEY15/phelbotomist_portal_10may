import React from "react";
import PropTypes from "prop-types";
import { Col, Form, Row } from "react-bootstrap";
import { InfoCircleFill } from "react-bootstrap-icons";
import { Markdown } from "@storybook/blocks";

var groupAs;
function FormInput(props) {
  props.groupAs === "row" ? (groupAs = Row) : (groupAs = Col);

  console.log("errors: ", props.errors);
  return (
    <>
      <Form.Group className={props.className} key={props.key}>
        <Form.Label className="labels">{props.required?(<><span className="asterisk">*</span>{props.label}</>):props.label}</Form.Label>
        {props.type !== "select" && (
          <Form.Control
            type={props.type}
            name={props.name}
            as={(props.as && props.as) || Form.Control}
            required
            placeholder={props.placeholder}
            size={props.size}
            readOnly={props.readOnly}
            disabled={props.disabled}
            value={props.value}
            onChange={props.onChange}
            aria-describedby={props.aria_describedby}
            isInvalid={props.touched && !!props.error}
          />
        )}
        {props.type === "select" && (
          <Form.Select aria-label="Default select example"  placeholder={props.placeholder} isInvalid={props.touched && !!props.error}>
            <option >{props.placeholder}</option>
            {props.options.map((option) => (
              <option value={option.toLowerCase()}>{option}</option>
            ))}
          </Form.Select>
        )}
        <Form.Text id={props.aria_describedby} muted={props.muted}>
          {props.helpText && <Markdown>{props.helpText}</Markdown>}
        </Form.Text>
        <Form.Control.Feedback type="invalid">
          <InfoCircleFill /> {props.error}
        </Form.Control.Feedback>
      </Form.Group>
    </>
  );
}

export default FormInput;

FormInput.propTypes = {
  /**
   * Name the field with this:
   */
  label: PropTypes.string.isRequired,
  /**
   * Specify the type of your field with this:
   */
  type: PropTypes.string.isRequired,
  /**
   * Use when you want the field to act as some other element:
   */
  as: PropTypes.string,
  /**
   * Specify if some field is mandatory:
   */
  required: PropTypes.bool,
  /**
   * Text to guide user to fill in a respective field:
   */
  placeholder: PropTypes.string,
  /**
   * Decide the size of the field as per your needs:
   */
  size: PropTypes.oneOf(["sm", "text", "lg"]),
  /**
   * Don't want to keep a field editable? Try this one:
   */
  readOnly: PropTypes.bool,
  /**
   * Want to disable a field? Try this:
   */
  disabled: PropTypes.bool,
  /**
   * Used like a control id to show help text for a field:
   */
  aria_describedby: PropTypes.string,
  /**
   * Show help text for a field:
   */
  helpText: PropTypes.string,
  /**
   * Control id to for a field:
   */
  controlId: PropTypes.string,
  /**
   * Apply css to the field:
   */
  className: PropTypes.string,
};

FormInput.defaultProps = {
  label: "Email",
  type: "email",
  required: true,
  placeholder: "Enter you email address...",
  size: "text",
  readOnly: false,
  disabled: false,
};
