import React from "react";
import { useState } from "react";
import { Form, Col, Row } from "react-bootstrap";
import { Formik } from "formik";
import { Button } from "../Buttons/Button";
import SuccessModal from "../Modals/Modal";
import FormInput from "./FormInput";

const EventGrid = ({ fields, validationSchema }) => {
  const generateInitialValues = (fields) => {
    const initialValues = {};
    fields.rows.forEach((row, rowIndex) => {
      row.forEach((field, colIndex) => {
        initialValues[field.name] = "";
      });
    });
    return initialValues;
  };

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);

  const handleShow = () => setShow(true);
  return (
    <Formik
      validationSchema={validationSchema}
      onSubmit={(values) => {
        handleShow();
        console.log("Submitted values:", values);
      }}
      initialValues={generateInitialValues(fields)}
    >
      {({ handleSubmit, handleChange, values, touched, errors }) => (
        <Form noValidate onSubmit={handleSubmit} className="text-left form-wrapper">
          {fields.rows.map((rows, rowIndex) => (
            <Row key={rowIndex}>
              {rows.map((col, colIndex) => (
                <Col key={colIndex}>
                  {col.type !== "button" && (
                    <FormInput
                      key={colIndex}
                      className={"inputs"}
                      {...col}
                      value={values[col.name]}
                      onChange={handleChange}
                      error={errors[col.name]}
                      touched={touched[col.name]}
                    />
                  )}
                  {col.type === "button" && (
                    <>
                      <div className="m-3 p-2">
                        <Form.Label className="labels">&nbsp;</Form.Label>
                        <Button
                          type="submit"
                          className="buttons custom-button"
                          onClick={!errors ? handleShow : null}
                          label={col.label}
                          variant={col.variant}
                        />
                        {show && (
                          <SuccessModal
                            key={colIndex}
                            className="btn  w-100 mx-2 buttons btn-primary"
                            label={col.label}
                            show={show}
                            handleClose={handleClose}
                            handleShow={handleShow}
                            errors={errors}
                          />
                        )}
                      </div>
                    </>
                  )}
                </Col>
              ))}
            </Row>
          ))}
        </Form>
      )}
    </Formik>
  );
};

export default EventGrid;
