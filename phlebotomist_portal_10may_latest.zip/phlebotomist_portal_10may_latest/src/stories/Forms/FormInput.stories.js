import FormInput from './FormInput';

export default {
  title: 'Components/Forms/FormInput',
  component: FormInput,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export const Default = {
  args: {
    label: 'Email',
    type: 'email',
    required: true,
    placeholder: 'Enter you email address...',
    size: 'text',
    readOnly: false,
    disabled: false,
    className:'m-3 p-2',
    groupAs:'row'
  },
};


