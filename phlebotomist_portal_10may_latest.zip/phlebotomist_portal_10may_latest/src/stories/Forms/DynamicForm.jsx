import Form from "react-bootstrap/Form";
import FormInput from "./FormInput";
import { Button } from "../Buttons/Button";
import * as formik from "formik";

var groupAs;
const DynamicForm = (props) => {
  const { Formik } = formik;

  const generateInitialValues = (fields) => {
    const initialValues = {};
    fields.forEach((field) => {
      initialValues[field.name] = "";
    });
    return initialValues;
  };

  return (
    <Formik
      validationSchema={props.validationSchema}
      onSubmit={(values) => {
        console.log("Submitted values:", values);
      }}
      initialValues={generateInitialValues(props.fields)}
    >
      {({ handleSubmit, handleChange, values, touched, errors }) => (
        <Form
          noValidate
          onSubmit={handleSubmit}
          className="text-left form-wrapper"
        >
          {props.fields.map((field) => (
            <Form.Group key={field.controlId}>
              {field.type === "button" || field.type === "submit" ? (
                <div className="m-3 p-2">
                  <Button
                    type={field.type}
                    size={field.size}
                    className={field.className}
                    variant={field.variant}
                    label={field.label}
                  />
                </div>
              ) : (
                <FormInput
                  key={field.controlId}
                  className="inputs"
                  type={field.type}
                  {...field}
                  value={values[field.name]}
                  onChange={handleChange}
                  error={errors[field.name]}
                  touched={touched[field.name]}
                />
              )}
            </Form.Group>
          ))}
        </Form>
      )}
    </Formik>
  );
};

export default DynamicForm;
const fields = [
  {
    controlId: 1,
    label: "Email",
    type: "email",
    as: "",
    required: true,
    placeholder: "Enter you email address...",
    size: "text",
    readOnly: false,
    disabled: false,
  },
  {
    controlId: 2,
    label: "Password",
    type: "password",
    as: "",
    required: true,
    placeholder: "Enter you password",
    size: "text",
    readOnly: false,
    disabled: false,
  },
  {
    controlId: 3,
    label: "Name",
    type: "name",
    as: "",
    required: true,
    placeholder: "Enter you name",
    size: "text",
    readOnly: false,
    disabled: false,
  },
];
DynamicForm.defaultProps = {
  fields: fields,
};
