import React from "react";
import LoggedOutLayout from "./LoggedOutLayout";
import logoSrc from "../../assets/mhc.png";
import doctorBag from "../../assets/icons/HCP icon.svg";
import admin from "../../assets/icons/admin icon.svg";
import { OvalButton } from "../Buttons/Button.stories";

export default {
  title: "Components/LoggedOutScreens/LoggedOutLayout",
  component: LoggedOutLayout,

  /* Center the component in Storybook UI */
  parameters: {
    layout: "centered",
  },

  /* Argument types for controlling props in Storybook UI */
  argTypes: {
    logoSrc: {
      control: { type: "file" },
    },
    title: {
      control: { type: "text" },
    },
    className: {
      control: { type: "text" },
    },
    children: {
      control: { type: "node" },
    },
  },
  tags: ['autodocs'],
};

const Template = (args) => <LoggedOutLayout {...args} />;

/* Default Story*/
export const Default = Template.bind({});
Default.args = {
  logoSrc: logoSrc,
  title: "Log in",
};


/* Story for LogIn */
export const LogIn = (args) => (

  <LoggedOutLayout title={"Log in"} logoSrc={logoSrc} {...args}>
    <OvalButton
      variant={"olive"}
      label={"Health Professional"}
      size={"medium"}
      svg={doctorBag}
    />
    <OvalButton
      variant={"offwhite"}
      label={"Admin"}
      size={"medium"}
      svg={admin}
    />
  </LoggedOutLayout>

);

