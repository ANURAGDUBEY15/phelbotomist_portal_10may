import React from "react";
import { Navbar } from "react-bootstrap";
import PropTypes from "prop-types";
import { Button } from "../Buttons/Button"

const Header = ({ title, img }) => {
  const items = [
    { label: 'Manage account', href: '/account' },
    { label: 'Change password', href: '/change-password' },
    { label: 'Enable MFA', href: '/enable-mfa' },
    { label: 'Notifications', href: '/notifications' },
    { label: 'Messages', href: '/messages' }
  ];

  const username = "David Nichols";

  /*Function to extract initials from username */
  const getInitials = (name) => {
    return name
      .split(" ")
      .map((part) => part.charAt(0).toUpperCase())
      .join("");
  };

  /*Function to store initials using getInitials method */
  const initials = getInitials(username);

  return (
    <>
      <Navbar>
        <div className="page-header w-100">
          <h1>{title}</h1>
          <div className="btn-toolbar mb-2 mb-md-0">
            <div className="dropdown profile-dropdown-wrapper">
              <Button variant="white" className="btn" type="dropdown" id="#" items={items} svg={img} />
              <Button variant="grey" type="dropdown" className="btn btn-profile" label={initials} items={items} username={username} initials={initials}> </Button>
            </div>
          </div>
        </div>
      </Navbar>
    </>

  );
};

Header.propTypes = {
  /**
   * Title content
   */
  title: PropTypes.string.isRequired,
  /**
   * Image source
   */
  img: PropTypes.string.isRequired,
  /**
   * Button label
   */
  initials: PropTypes.string
};


export default Header;
