import React from "react";
import { Image, Nav } from "react-bootstrap";
import Navbar from 'react-bootstrap/Navbar';
import PropTypes from "prop-types";
import Container from 'react-bootstrap/Container';
import { Button } from "../Buttons/Button";

const Sidebar = ({ links, logo, buttonLabel }) => {
  return (
    <div className="sidebar">
      <Navbar expand="lg" className="bg-body-tertiary">
        <Container className="d-inline p-0">
          <Navbar.Brand>
            <Image src={logo} alt="My Health Checked" className="d-block m-auto" />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="flex-column">
              {links.map((item, index) => (
                <Nav.Item key={index}>
                  <Nav.Link href={item.href}>
                    <div className="nav-icon">
                      <Image src={item.icon} alt={item.alt} className="icon" />
                    </div>
                    {item.text}
                  </Nav.Link>
                </Nav.Item>
              ))}
            </Nav>
          </Navbar.Collapse>
          <Button variant={"outline"} className="logout-btn" label={buttonLabel}></Button>
        </Container>
      </Navbar>
    </div>
  );
};

Sidebar.propTypes = {
  /**
   * Logo source
   */
  logo: PropTypes.string.isRequired,
  /**
   * Array of sidebar links
   */
  sidebarLinks: PropTypes.arrayOf(
    PropTypes.shape({
      /**
       * Text for the link
       */
      text: PropTypes.string.isRequired,
      /**
       * Icon source for the link
       */
      icon: PropTypes.string.isRequired,
      /**
       * Alternate text for the icon
       */
      alt: PropTypes.string.isRequired
    })
  ),
  /**
   * Content to be rendered inside the layout
   */
  children: PropTypes.node,
  /**
   * Image source
   */
  img: PropTypes.string,
  /**
   * Title of the page
   */
  pageTitle: PropTypes.string
};


export default Sidebar;
