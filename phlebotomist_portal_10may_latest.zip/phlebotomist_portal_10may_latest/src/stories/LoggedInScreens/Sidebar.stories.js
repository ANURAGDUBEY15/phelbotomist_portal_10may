import React from "react";
import Sidebar from "./Sidebar";
import logo from "../../assets/mhc.png";
import calendarIcon from "../../../src/assets/calendar-icon.svg";
import testsIcon from "../../../src/assets/tests-icon.svg";
import unionIcon from "../../../src/assets/union.svg";
import icon from "../../../src/assets/icon.svg";

export default {
  title: "Components/LoggedInScreens/Sidebar",
  component: Sidebar,
  argTypes: {
    links: {
      control: {
        type: "array",
        separator: ", ",
      },
    },
    logo: { control: "file" },
  },
  tags: ['autodocs'],
};

const Template = (args) => <Sidebar {...args} />;

export const Default = Template.bind({});
Default.args = {
  links: [
    { text: "Patient record", icon: calendarIcon },
    { text: "Appt.record", icon: testsIcon },
    { text: "Account", icon: unionIcon },
    { text: "Resources", icon: icon },
  ],
  logo: logo,
};