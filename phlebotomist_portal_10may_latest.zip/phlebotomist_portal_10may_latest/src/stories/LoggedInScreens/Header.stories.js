import React from "react";
import Header from "./Header";
import notification from "../../assets/notification.svg";

export default {
  title: "Components/LoggedInScreens/Header",
  component: Header,
  argTypes: {
    title: {
      control: { type: "text" },
    },
    img: { control: "file" },
    initials: {
      control: { type: "text" },
    },
  },
  tags: ['autodocs'],
};

const Template = (args) => <Header {...args} />;

export const Default = Template.bind({});
Default.args = {
  title: "PATIENT RECORD", // Set a default value for the title prop
  img: notification, // Pass the imported image directly
};
