import React from "react";
import LoggedInLayout from "./LoggedInLayout";
import logo from "../../assets/mhc.png";
import calendarIcon from "../../assets/calendar-icon.svg";
import testsIcon from "../../assets/tests-icon.svg";
import unionIcon from "../../assets/union.svg";
import icon from "../../assets/icon.svg";
import img from "../../assets/notification.svg"

export default {
  title: "Components/LoggedInScreens/LoggedInLayout",
  component: LoggedInLayout,
  tags: ['autodocs'],
  argTypes: {
    pageTitle: {
      control: { type: "text" },
    },
    logo: {
      control: { type: "file" },
    },
    img: {
      control: { type: "file" },
    },
  },
};

const Template = (args) => <LoggedInLayout {...args} />;

export const Default = Template.bind({});
Default.args = {
  logo: logo,
  pageTitle: "",
  buttonLabel:'Logout',
  sidebarLinks: [
    { text: "Patient record", icon: calendarIcon }, // Assign the imported icon images
    { text: "Appt.record", icon: testsIcon },
    { text: "Account", icon: unionIcon },
    { text: "Resources", icon: icon },
  ],
  img :img,
};
