import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import Header from "./Header";
import Sidebar from "./Sidebar";
import PropTypes from "prop-types";

const LoggedInLayout = ({ logo, sidebarLinks, children, img, buttonLabel, pageTitle }) => {
  return (
    <>
      <Container fluid className="vh-100">
        <Row className="h-100">
          <Col className="sidebar-container">
            <Sidebar links={sidebarLinks} logo={logo} buttonLabel={buttonLabel}/>
          </Col>
          <Col xs={9} md={9} lg={10} className="main-content">
            <Header title={pageTitle} img={img} />
            <main>
              {children}
            </main>
          </Col>
        </Row>
      </Container>
    </>
  );
};

LoggedInLayout.propTypes = {
  /**
   * Logo source
   */
  logo: PropTypes.string.isRequired,
  /**
   * Array of sidebar links
   */
  sidebarLinks: PropTypes.array,
  /**
   * Content to be rendered inside the layout
   */
  children: PropTypes.node.isRequired,
  /**
   * Image source
   */
  img: PropTypes.string,
  /**
   * Title of the page
   */
  pageTitle: PropTypes.string.isRequired
};


export default LoggedInLayout;
