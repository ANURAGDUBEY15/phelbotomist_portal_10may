import React from "react";
import testsIcon from "../src/assets/tests-icon.svg";
import unionIcon from "../src/assets/union.svg";
import calendarIcon from "../src/assets/calendar-icon.svg";
import icon from "../src/assets/icon.svg";
import LoggedInLayout from "./stories/LoggedInScreens/LoggedInLayout";
import logo from "../src/assets/mhc.png";
import img from "../src/assets/notification.svg";
import Page from "../src/Page";
import LoggedOutLayout from "./stories/LoggedOutScreens/LoggedOutLayout";

function App() {
  const links = [
    {
      text: "Patient record",
      icon: calendarIcon,
      alt: "Patient record icon",
      href: "/patient-record",
    },
    {
      text: "Appt. record",
      icon: testsIcon,
      alt: "Appointment record icon",
      href: "/appointment-record",
    },
    { text: "Account", icon: unionIcon, alt: "Account icon", href: "/account" },
    {
      text: "Resources",
      icon: icon,
      alt: "Resources icon",
      href: "/resources",
    },
  ];
  let isLoggedIn = true;

  const TitleName = () => {
    let titleName =
      window.location.pathname === "/"
        ? "PATIENT RECORD"
        : window.location.pathname.split("/")[1].replace("-", " ");
    return titleName;
  };

  return (
    <>
      {isLoggedIn ? (
        <LoggedInLayout
          logo={logo}
          pageTitle={TitleName()}
          sidebarLinks={links || []}
          img={img}
          buttonLabel={"Logout"}
        >
          <Page />
        </LoggedInLayout>
      ) : (
        <LoggedOutLayout title={"Log in"} logoSrc={logo} className="login-form">
          <Page />
        </LoggedOutLayout>
      )}
    </>
  );
}

export default App;
