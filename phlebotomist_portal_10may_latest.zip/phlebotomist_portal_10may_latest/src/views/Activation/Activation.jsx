import React from "react";
import EvenGrid from "../../stories/Forms/EvenGrid";
import { activationShema } from "../../stories/Forms/validationSchema";
import { Container } from "react-bootstrap";
import { activationFields } from "../../stories/Forms/fields";

const Activation = () => {
  return (
    <Container>
      <p className="mx-4">Enter the fields below to create account</p>
      <EvenGrid fields={activationFields} validationSchema={activationShema} />
    </Container>
  );
};

export default Activation;
