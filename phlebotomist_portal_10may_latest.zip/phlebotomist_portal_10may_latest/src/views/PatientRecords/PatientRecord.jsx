import React from 'react'

function PatientRecord() {
  return (
    <div></div>
  )
}

export default PatientRecord