import React from 'react'

function AppointmentRecord() {
  return (
    <div>AppointmentRecord</div>
  )
}

export default AppointmentRecord