import React from 'react'
import DynamicForm from '../stories/Forms/DynamicForm'
const fields=[
  {
    controlId: '1',
    label: 'Confirm MFA',
    type: 'number',
    name: 'confirmmfa',
    as: '',
    required: true,
    placeholder: 'Enter your auth code',
    size: 'lg',
    readOnly: false,
    disabled: false,
    aria_describedby: 'val1',
    className: 'm-3 p-2',
  },
]

const ConfirmMFA = () => {
  return (
    <div>
      <DynamicForm fields={fields}/>
    </div>
  )
}

export default ConfirmMFA