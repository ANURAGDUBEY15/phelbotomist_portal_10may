import React from "react";
import { OvalButton } from "../stories/Buttons/Button.stories";
import doctorBag from "../assets/icons/HCP icon.svg";
import admin from "../assets/icons/admin icon.svg";

function LoginPage() {
  return (
    <>
      <OvalButton
        variant={"olive"}
        label={"Health Professional"}
        size={"medium"}
        svg={doctorBag}
        href="/login-form"
      />
      <OvalButton
        variant={"offwhite"}
        label={"Admin"}
        size={"medium"}
        svg={admin}
        href="/login-form"
      />
    </>
  );
}

export default LoginPage;
