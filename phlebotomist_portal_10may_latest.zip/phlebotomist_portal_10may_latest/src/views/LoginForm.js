import React from "react";
import DynamicForm from '../stories/Forms/DynamicForm'
import { loginSchema } from "../stories/Forms/validationSchema";
import { Container } from "react-bootstrap";
import { loginFields } from "../stories/Forms/fields";

function LoginForm() {
  return (
    <>
      <Container className="text-center">
        <DynamicForm fields={loginFields} validationSchema={loginSchema} />
      </Container>
    </>
  );
}

export default LoginForm;
