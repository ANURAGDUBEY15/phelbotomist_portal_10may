import React from 'react'

function Accounts() {
  return (
    <div>Accounts</div>
  )
}

export default Accounts